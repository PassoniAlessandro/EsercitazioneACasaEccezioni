
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Contatore c= new Contatore();
        String scelta;
        int posizione=0;
        System.out.println("inserire un numero o x per uscire");
        scelta=in.next();

        try {
            while(!scelta.equals("x")){

                posizione++;
                System.out.println("inserire un numero o x per uscire");
                scelta=in.next();

            }
        } catch (ArrayPienoException e ) {


        }





    }
    }
