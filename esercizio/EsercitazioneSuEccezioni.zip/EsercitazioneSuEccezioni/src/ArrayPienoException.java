public class ArrayPienoException extends Exception{
    public ArrayPienoException(String s){
        super(s);

    }

}
