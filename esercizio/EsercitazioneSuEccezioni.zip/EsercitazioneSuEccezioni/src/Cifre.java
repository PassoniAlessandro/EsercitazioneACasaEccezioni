import java.sql.Timestamp;

public class Cifre {
    private int  numero;
    Timestamp input;
    public Cifre (int numero,long input){
        this.numero=numero;
        this.input= new Timestamp(input);

    }

    public void setInput(long input){

        this.input=new Timestamp(input);
    }
    public int getNumero(){
        return numero;

    }
    public Timestamp getInput(){

        return input;
    }

}
