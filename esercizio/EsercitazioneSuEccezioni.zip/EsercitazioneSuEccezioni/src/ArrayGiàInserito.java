public class ArrayGiàInserito extends Exception{
    public ArrayGiàInserito(String s){
        super(s);
    }
}
