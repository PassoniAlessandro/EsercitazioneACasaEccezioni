public class Contatore {
    private Cifre array[];
    private Cifre numero;

    public Contatore() {
        array = new Cifre[3];
    }


    private boolean CheckPieno() {
        boolean pieno = false;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == null) {
                return false;
            }
        }
        return true;
    }
    public void AggiungiNumero(Cifre numero, int posizione) throws ArrayPienoException {
        if (CheckPieno()) {
            throw new ArrayPienoException("nell'array non c'è più spazio");
        }
        array[posizione] = numero;

    }
 private boolean CheckGiàInserito(){
        boolean giainserito=false;
        for(int i=0;i<array.length;i++){
            if(array[i]==numero){
                return false;
            }
        }
       return true;




     }
    public void AggiungiNumeroGiàEsistente (Cifre numero,int posizione) throws ArrayGiàInserito{
        if(CheckGiàInserito()){
            throw new ArrayGiàInserito("il tuo numero è già stato inserito");

        }
        array[posizione] = numero;

    }




}
